<?php
/**
 * Plugin Name: CPPR Public Policy Stockroom Portal
 * Plugin URI: https://affanaamin.github.io/cppr-stockroom/
 * Description: Centralized Public Policy & Legal Stockroom Portal for CPPR IMSciences Peshawar. Insert shortcode [cppr_stockroom] on any page.
 * Version: 2.0.0
 * Author: Centre for Public Policy Research (CPPR)
 * Author URI: https://imsciences.edu.pk/
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class CPPR_Stockroom_Plugin {

    public function __construct() {
        add_shortcode('cppr_stockroom', array($this, 'render_stockroom_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_stockroom_assets'));
    }

    public function register_stockroom_assets() {
        wp_register_style('cppr-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap', array(), null);
        wp_register_style('cppr-stockroom-style', plugins_url('stockroom-style.css', __FILE__), array('cppr-google-fonts'), '2.0.0');
        wp_register_script('cppr-documents-data', plugins_url('documents_data.js', __FILE__), array(), '2.0.0', true);
        wp_register_script('cppr-stockroom-script', plugins_url('stockroom-script.js', __FILE__), array('jquery', 'cppr-documents-data'), '2.0.0', true);
    }

    public function render_stockroom_shortcode($atts) {
        wp_enqueue_style('cppr-google-fonts');
        wp_enqueue_style('cppr-stockroom-style');
        wp_enqueue_script('cppr-documents-data');
        wp_enqueue_script('cppr-stockroom-script');

        ob_start();
        ?>
        <div id="cppr-stockroom-root">
            <?php include(plugin_dir_path(__FILE__) . 'stockroom-template.php'); ?>
        </div>
        <?php
        return ob_get_clean();
    }
}

new CPPR_Stockroom_Plugin();

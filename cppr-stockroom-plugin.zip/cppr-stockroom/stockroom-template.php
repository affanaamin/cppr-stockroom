
    <!-- Admin Password Overlay -->
    <div id="adminOverlay" class="admin-overlay hidden">
      <div class="admin-login-card">
        <div style="font-size: 2.2rem; margin-bottom: 0.5rem">🔐</div>
        <h2>CPPR Admin Access</h2>
        <p>Enter the administrator password to enable content editing mode.</p>
        <input
          type="password"
          id="adminPassInput"
          placeholder="Enter password"
          onkeydown="if (event.key === 'Enter') adminLogin();"
        />
        <button class="login-btn" onclick="adminLogin()">
          Unlock Admin Panel
        </button>
        <div id="adminLoginError" class="login-error">
          Incorrect password. Please try again.
        </div>
        <button class="skip-btn" onclick="skipAdminLogin()">
          Continue as visitor →
        </button>
      </div>
    </div>

    <!-- Admin Toolbar (visible only in admin mode) -->
    <div class="admin-toolbar">
      <div class="admin-label"><span class="dot"></span> Admin Mode Active</div>
      <div class="admin-actions">
        <button
          class="admin-btn btn-edit"
          id="globalEditToggleBtn"
          onclick="toggleGlobalEdit()"
        >
          🎯 Select to Edit (OFF)
        </button>
        <button class="admin-btn btn-add" onclick="showAddDocModal()">
          ➕ Add Document
        </button>
        <button class="admin-btn btn-export" onclick="exportHTML()">
          💾 Export HTML
        </button>
        <button class="admin-btn btn-logout" onclick="adminLogout()">
          🚪 Logout
        </button>
      </div>
    </div>

    <!-- Add Document Modal -->
    <div id="addDocModal" class="add-doc-modal">
      <div class="add-doc-form">
        <h3>➕ Add New Stockroom Document</h3>
        <label>Document Title *</label>
        <input
          type="text"
          id="newDocTitle"
          placeholder="e.g. The KP Local Government Act, 2013"
        />
        <label>Document Type *</label>
        <select id="newDocType">
          <option value="Act">Act / Law</option>
          <option value="Rules">Rules</option>
          <option value="Rules of Business">Rules of Business</option>
          <option value="By-Laws">By-Laws</option>
          <option value="Notification">Notification / Order</option>
          <option value="SOPs">SOPs / Manual / Guidelines</option>
          <option value="Policy Schedule">Policy Schedule</option>
          <option value="Research Study">Research Study</option>
        </select>
        <label>Policy Sector *</label>
        <select id="newDocSector">
          <option value="Governance">Governance</option>
          <option value="Health">Health</option>
          <option value="Higher Education">Higher Education</option>
          <option value="Law &amp; Justice">Law &amp; Justice</option>
          <option value="Finance &amp; Taxation">Finance &amp; Taxation</option>
          <option value="Social Welfare &amp; Human Rights">
            Social Welfare &amp; Human Rights
          </option>
          <option value="Public Safety &amp; Security">
            Public Safety &amp; Security
          </option>
          <option value="Transport &amp; Infrastructure">
            Transport &amp; Infrastructure
          </option>
          <option value="Industries &amp; Commerce">
            Industries &amp; Commerce
          </option>
          <option value="Housing &amp; Land Revenue">
            Housing &amp; Land Revenue
          </option>
        </select>
        <label>Issuing Authority *</label>
        <input
          type="text"
          id="newDocAuth"
          placeholder="e.g. Provincial Assembly of Khyber Pakhtunkhwa"
        />
        <label>Date / Year *</label>
        <input
          type="text"
          id="newDocDate"
          placeholder="e.g. 2024 or 15th March, 2024"
        />
        <label>Google Drive Link (optional)</label>
        <input
          type="url"
          id="newDocDrive"
          placeholder="https://drive.google.com/file/d/..."
        />
        <label>Executive Summary *</label>
        <textarea
          id="newDocSummary"
          rows="3"
          placeholder="Brief description of the document..."
        ></textarea>
        <div class="form-actions">
          <button class="cancel-btn" onclick="hideAddDocModal()">Cancel</button>
          <button class="submit-btn" onclick="addNewDocument()">
            Add Document
          </button>
        </div>
      </div>
    </div>

    <div class="top-bar">
      <div
        class="brand-logo"
        style="display: flex; align-items: center; gap: 0.8rem"
      >
        <img
          src="assets/cppr_logo.png"
          alt="CPPR Logo"
          style="height: 42px; width: auto; border-radius: 4px"
          onerror="this.style.display = 'none'"
        />
        <div>
          <h2 data-editable="true" style="margin: 0; font-size: 1.25rem">
            Centre for Public Policy Research (CPPR)
          </h2>
          <small
            data-editable="true"
            style="color: var(--muted-color); font-weight: 500"
            >IMSciences Peshawar — Premier Public Policy Think Tank</small
          >
        </div>
      </div>
      <button class="theme-toggle" onclick="toggleDarkMode()">
        <span id="themeLabel">Dark Mode</span>
      </button>
    </div>

    <div class="header">
      <h1 data-editable="true">Centre for Public Policy Research (CPPR)</h1>
      <p data-editable="true">
        Institute of Management Sciences (IMSciences), Peshawar — Evidence-Based
        Policy Research & Digital Policy Stockroom Platform
      </p>
    </div>

    <!-- Top Navigation Tabs -->
    <div class="nav-tabs">
      <button class="tab-btn active" onclick="switchTab('tabHome')">
        🏠 CPPR Home
      </button>
      <button class="tab-btn" onclick="switchTab('tabResearch')">
        🔬 Research & Policy Thrusts
      </button>
      <button class="tab-btn" onclick="switchTab('tabStockroom')">
        📦 Public Policy Stockroom
      </button>
      <button class="tab-btn" onclick="switchTab('tabContact')">
        ✉️ Contact & About
      </button>
    </div>

    <!-- TAB 1: CPPR HOME PAGE -->
    <div id="tabHome" class="tab-content active">
      <div class="hero-banner">
        <h2
          data-editable="true"
          style="color: #1f4e78; font-size: 1.6rem; margin-bottom: 0.5rem"
        >
          Centre for Public Policy Research (CPPR)
        </h2>
        <p
          style="
            color: var(--muted-color);
            font-size: 1rem;
            line-height: 1.6;
            max-width: 900px;
          "
        >
          The <strong>Centre for Public Policy Research (CPPR)</strong> at the
          Institute of Management Sciences (IMSciences), Peshawar, is a premier
          policy think tank dedicated to advancing evidence-based research,
          technical policy support, baseline evaluations, and legislative
          documentation.
        </p>
        <div
          style="
            margin-top: 1.2rem;
            display: flex;
            gap: 0.75rem;
            flex-wrap: wrap;
          "
        >
          <button
            onclick="switchTab('tabStockroom')"
            style="
              background: #1f4e78;
              color: white;
              border: none;
              padding: 0.75rem 1.4rem;
              border-radius: 8px;
              font-weight: 600;
              font-size: 0.95rem;
              cursor: pointer;
              display: inline-flex;
              align-items: center;
              gap: 0.5rem;
              transition: background 0.2s;
            "
          >
            📦 Access Public Policy Stockroom
          </button>
        </div>
      </div>

      <!-- Featured Stockroom Spotlight Banner -->
      <div
        style="
          background: linear-gradient(
            135deg,
            rgba(31, 78, 120, 0.06),
            rgba(59, 130, 246, 0.06)
          );
          border: 1px solid rgba(31, 78, 120, 0.2);
          border-radius: 12px;
          padding: 1.5rem 1.8rem;
          margin-bottom: 2rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        "
      >
        <div
          style="
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
          "
        >
          <div>
            <span class="badge badge-act" style="margin-bottom: 0.4rem"
              >Flagship Digital Feature</span
            >
            <h3 style="color: #1f4e78; font-size: 1.3rem; margin: 0.2rem 0">
              Public Policy Stockroom Platform
            </h3>
            <p
              style="
                color: var(--muted-color);
                font-size: 0.95rem;
                margin-top: 0.3rem;
              "
            >
              A centralized digital repository housing 91+ verified primary
              laws, rules of business, SOPs, and governance policies across 10
              policy sectors with PDF previewers and executive summaries.
            </p>
          </div>
          <button
            onclick="switchTab('tabStockroom')"
            class="btn-sm btn-preview"
            style="
              padding: 0.6rem 1.2rem;
              font-size: 0.9rem;
              border-radius: 8px;
            "
          >
            Explore Stockroom ➔
          </button>
        </div>
        <div
          class="stats-grid"
          style="
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            margin-top: 0.5rem;
          "
        >
          <div class="stat-card" style="padding: 0.8rem">
            <div class="num" style="font-size: 1.4rem" data-editable="true">
              91
            </div>
            <div class="label" data-editable="true">
              Primary Policy Instruments
            </div>
          </div>
          <div class="stat-card" style="padding: 0.8rem">
            <div class="num" style="font-size: 1.4rem" data-editable="true">
              76
            </div>
            <div class="label" data-editable="true">Acts & Laws</div>
          </div>
          <div class="stat-card" style="padding: 0.8rem">
            <div class="num" style="font-size: 1.4rem" data-editable="true">
              15
            </div>
            <div class="label" data-editable="true">Rules & SOPs</div>
          </div>
          <div class="stat-card" style="padding: 0.8rem">
            <div class="num" style="font-size: 1.4rem" data-editable="true">
              10
            </div>
            <div class="label" data-editable="true">Policy Sectors</div>
          </div>
        </div>
      </div>

      <!-- 1. Background & Rationale and Purpose Cards -->
      <div class="about-section-grid">
        <div class="about-card">
          <h3 data-editable="true">
            🏛️ Centre for Public Policy Research (CPPR)
          </h3>
          <p data-editable="true">
            The <strong>Centre for Public Policy Research (CPPR)</strong> at the
            Institute of Management Sciences (IMSciences), Peshawar, is a
            leading policy think tank dedicated to advancing research and
            providing technical support to the government on various policy
            matters.
          </p>
          <p>
            CPPR specializes in coordinating quantitative and qualitative
            baselines, impact assessments, perception surveys, third-party
            validations, and monitoring and evaluation services. With a strong
            focus on humanitarian and developmental research, the Centre boasts
            expertise in research design, technical methodologies, data
            management, and analysis.
          </p>
        </div>

        <div class="about-card">
          <h3 data-editable="true">📜 Background & Purpose of the Stockroom</h3>
          <p data-editable="true">
            Public policy practitioners, researchers, students, academics,
            government officials, media professionals, development partners, and
            civil society organizations often require access to a wide range of
            laws, Acts, rules of business, policies, strategies, and SOPs.
            However, these resources are generally dispersed across different
            departments and archives, making retrieval time-consuming and
            inefficient.
          </p>
          <p>
            To address this gap, CPPR established the
            <strong>Public Policy Stockroom</strong> to create a centralized,
            organized, and regularly updated repository of Pakistan's public
            policy and legal documents. It enables users to find relevant
            information in a few simple clicks, reducing duplication of effort
            and supporting evidence-based research.
          </p>
        </div>
      </div>

      <!-- 5. Featured Legislation Showcase -->
      <h3 data-editable="true" style="color: #1f4e78; margin-bottom: 1rem">
        Featured Key Legislation
      </h3>
      <div class="feature-grid">
        <div class="feature-card">
          <span class="badge badge-act">Act</span>
          <h3>
            The North-West Frontier Province Civil Courts (amendment) Act, 2009
          </h3>
          <p>
            Enacts statutory provisions for judicial administration, legal
            proceedings, court jurisdiction, and public ombudsman oversight.
          </p>
          <div style="margin-top: 1rem; display: flex; gap: 0.5rem">
            <button
              class="btn-sm btn-preview"
              onclick="openPreview( 'The North-West Frontier Province Civil Courts (amendment) Act, 2009', 'completed/Civil-Courts-Amendment-Act-2009-Act.pdf', 'https://drive.google.com/file/d/1QPjaPn12LZPOZGJK782ZDXF8sDBWs4B-/view?usp=sharing')"
            >
              Preview Document
            </button>
          </div>
        </div>
        <div class="feature-card">
          <span class="badge badge-act">Act</span>
          <h3>
            The Code of Criminal Procedure (north-West Frontier Province)
            (amendment) Act, 2008
          </h3>
          <p>
            Enacts statutory provisions for judicial administration, legal
            proceedings, court jurisdiction, and public ombudsman oversight.
          </p>
          <div style="margin-top: 1rem; display: flex; gap: 0.5rem">
            <button
              class="btn-sm btn-preview"
              onclick="openPreview( 'The Code of Criminal Procedure (north-West Frontier Province) (amendment) Act, 2008', 'completed/Code of Criminal Procedure.pdf', 'https://drive.google.com/file/d/1cPf8j9w2PRsupgkAWcNICRiTwIP2fO9T/view?usp=sharing')"
            >
              Preview Document
            </button>
          </div>
        </div>
        <div class="feature-card">
          <span class="badge badge-act">Act</span>
          <h3>
            The North-West Frontier Province Establishment of District
            Development Advisory Committees (amendment) Act, 2010
          </h3>
          <p>
            Official act establishing regulatory standards and administrative
            compliance for provincial public policy.
          </p>
          <div style="margin-top: 1rem; display: flex; gap: 0.5rem">
            <button
              class="btn-sm btn-preview"
              onclick="openPreview( 'The North-West Frontier Province Establishment of District Development Advisory Committees (amendment) Act, 2010', 'completed/Establishment-Of-District-Development-Advisory-Committees-Amendment-Act-2010-Act.pdf', 'https://drive.google.com/file/d/1JchhXBusmbP292FvttKM2OPgzWD4RtFl/view?usp=sharing')"
            >
              Preview Document
            </button>
          </div>
        </div>
        <div class="feature-card">
          <span class="badge badge-act">Act</span>
          <h3>
            The North-West Frontier Province Establishment of a Commission on
            the Status of Women Act, 2009
          </h3>
          <p>
            Enforces legal protection of fundamental rights, social welfare
            administration, human rights safeguards, and community support.
          </p>
          <div style="margin-top: 1rem; display: flex; gap: 0.5rem">
            <button
              class="btn-sm btn-preview"
              onclick="openPreview( 'The North-West Frontier Province Establishment of a Commission on the Status of Women Act, 2009', 'completed/Establishment-of-A-Commission-On-The-Status-Of-Women-Act.pdf', 'https://drive.google.com/file/d/1rbOgPVLZ59mRZhyBaojFaqG8dlJ5MtEw/view?usp=sharing')"
            >
              Preview Document
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB 2: CPPR RESEARCH & POLICY THRUSTS -->
    <div id="tabResearch" class="tab-content">
      <div style="margin-bottom: 1.5rem">
        <h2 style="color: #1f4e78; font-size: 1.5rem; margin-bottom: 0.5rem">
          CPPR Research & Policy Thrust Areas
        </h2>
        <p style="color: var(--muted-color); font-size: 1rem">
          CPPR conducts multi-disciplinary research, legislative analyses, and
          policy reviews across core public sector domains in Khyber Pakhtunkhwa
          and Pakistan.
        </p>
      </div>

      <!-- Major CPPR Projects & Baseline Studies Showcase -->
      <div
        style="
          background: linear-gradient(
            135deg,
            rgba(31, 78, 120, 0.05),
            rgba(59, 130, 246, 0.05)
          );
          border: 1px solid var(--border-color);
          border-radius: 16px;
          padding: 1.8rem;
          margin-bottom: 2.5rem;
          box-shadow: var(--shadow-sm);
        "
      >
        <div
          style="
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1.5rem;
          "
        >
          <div>
            <span class="badge badge-act" style="margin-bottom: 0.4rem"
              >Empirical Research & Field Studies</span
            >
            <h3 style="color: #1f4e78; font-size: 1.4rem; margin: 0.2rem 0">
              CPPR Flagship Research Projects & Baseline Studies
            </h3>
            <p
              style="
                color: var(--muted-color);
                font-size: 0.95rem;
                margin-top: 0.2rem;
              "
            >
              Key policy initiatives, impact assessments, digital readiness
              evaluations, and baseline surveys conducted by CPPR IMSciences
              Peshawar.
            </p>
          </div>
        </div>

        <div
          id="cpprProjectsGrid"
          style="
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
            gap: 1.4rem;
          "
        >
          <!-- Populated dynamically via JS -->
        </div>
      </div>

      <h3 style="color: #1f4e78; font-size: 1.3rem; margin-bottom: 1rem">
        Core Research Domain Directories
      </h3>
      <div class="dept-grid">
        <div class="dept-card">
          <h3>
            <span data-editable="true">🏛️ Governance</span>< & Local Government
          </h3>
          <div class="dept-count">Key Research Domain</div>
          <p
            style="
              font-size: 0.9rem;
              color: var(--muted-color);
              line-height: 1.6;
            "
          >
            Analysis of local council devolution, Tehsil Rules of Business,
            Village and Neighbourhood Council planning manuals, and provincial
            administrative structures.
          </p>
          <button
            class="btn-sm btn-preview"
            style="margin-top: 1rem"
            onclick="filterStockroomBySector('Governance')"
          >
            View Governance Policies ➔
          </button>
        </div>

        <div class="dept-card">
          <h3>💊 Healthcare & Public Health</h3>
          <div class="dept-count">Key Research Domain</div>
          <p
            style="
              font-size: 0.9rem;
              color: var(--muted-color);
              line-height: 1.6;
            "
          >
            Health sector baseline surveys, medical university governance
            charters, healthcare protection acts, and emergency health SOPs.
          </p>
          <button
            class="btn-sm btn-preview"
            style="margin-top: 1rem"
            onclick="filterStockroomBySector('Health')"
          >
            View Health Policies ➔
          </button>
        </div>

        <div class="dept-card">
          <h3>⚖️ Law, Justice & Human Rights</h3>
          <div class="dept-count">Key Research Domain</div>
          <p
            style="
              font-size: 0.9rem;
              color: var(--muted-color);
              line-height: 1.6;
            "
          >
            Judicial administration, Civil Courts amendments, Code of Criminal
            Procedure updates, and statutory commissions on the status of women.
          </p>
          <button
            class="btn-sm btn-preview"
            style="margin-top: 1rem"
            onclick="filterStockroomBySector('Law & Justice')"
          >
            View Law Policies ➔
          </button>
        </div>

        <div class="dept-card">
          <h3>💼 Economic Policy & Public Finance</h3>
          <div class="dept-count">Key Research Domain</div>
          <p
            style="
              font-size: 0.9rem;
              color: var(--muted-color);
              line-height: 1.6;
            "
          >
            Public procurement regulations (KPPRA), provincial financial rules,
            mineral sector taking-over acts, and commercial governance
            frameworks.
          </p>
          <button
            class="btn-sm btn-preview"
            style="margin-top: 1rem"
            onclick="filterStockroomBySector('Finance & Taxation')"
          >
            View Economic Policies ➔
          </button>
        </div>

        <div class="dept-card">
          <h3>🎓 Higher Education & Human Resource</h3>
          <div class="dept-count">Key Research Domain</div>
          <p
            style="
              font-size: 0.9rem;
              color: var(--muted-color);
              line-height: 1.6;
            "
          >
            University charter legislation, Civil Servants
            appointment/promotion/transfer rules, and youth development
            frameworks.
          </p>
          <button
            class="btn-sm btn-preview"
            style="margin-top: 1rem"
            onclick="filterStockroomBySector('Higher Education')"
          >
            View Education Policies ➔
          </button>
        </div>
      </div>
    </div>

    <!-- TAB 3: DEDICATED PUBLIC POLICY STOCKROOM -->
    <div id="tabStockroom" class="tab-content">
      <div style="margin-bottom: 1rem">
        <h2
          data-editable="true"
          style="color: #1f4e78; font-size: 1.5rem; margin-bottom: 0.3rem"
        >
          CPPR Public Policy Stockroom
        </h2>
        <p style="color: var(--muted-color); font-size: 0.95rem">
          Centralized Digital Repository of Primary Laws, Acts, Rules of
          Business, and Official SOPs (91 Documents & Research Studies)
        </p>
      </div>
      <div class="controls-card">
        <div class="search-row">
          <input
            type="text"
            id="searchInput"
            class="search-input"
            placeholder="Search"
            onkeyup="applyFilters()"
          />
          <button class="btn-reset" onclick="resetFilters()">
            Clear Filters
          </button>
        </div>

        <div class="filter-grid">
          <select
            id="sectorFilter"
            class="select-input"
            onchange="applyFilters()"
          >
            <option value="ALL">All Sectors</option>
            <option value="Finance & Taxation">Finance & Taxation</option>
            <option value="Governance">Governance</option>
            <option value="Health">Health</option>
            <option value="Higher Education">Higher Education</option>
            <option value="Housing & Land Revenue">
              Housing & Land Revenue
            </option>
            <option value="Industries & Commerce">Industries & Commerce</option>
            <option value="Law & Justice">Law & Justice</option>
            <option value="Public Safety & Security">
              Public Safety & Security
            </option>
            <option value="Social Welfare & Human Rights">
              Social Welfare & Human Rights
            </option>
            <option value="Transport & Infrastructure">
              Transport & Infrastructure
            </option>
          </select>

          <select
            id="typeFilter"
            class="select-input"
            onchange="applyFilters()"
          >
            <option value="ALL">All Document Types</option>
            <option value="Act">Acts / Laws</option>
            <option value="Rules">Rules</option>
            <option value="By-Laws">By-Laws</option>
            <option value="Rules of Business">Rules of Business</option>
            <option value="Notification">Notifications & Orders</option>
            <option value="SOPs">SOPs / Manuals / Guidelines</option>
          </select>

          <select
            id="yearFilter"
            class="select-input"
            onchange="applyFilters()"
          >
            <option value="ALL">All Years</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2015">2015</option>
            <option value="2017">2017</option>
            <option value="2019">2019</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
          </select>
        </div>
      </div>

      <div class="counter-bar">
        <span id="counterText">Showing 100 of 91 Documents</span>
        <div class="pagination-container">
          <label
            style="
              font-size: 0.85rem;
              font-weight: 600;
              color: var(--muted-color);
            "
            >Rows per page:</label
          >
          <select
            id="pageSizeSelect"
            class="select-input"
            style="width: auto; padding: 0.4rem 0.8rem; font-size: 0.85rem"
            onchange="changePageSize()"
          >
            <option value="15" selected>15</option>
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
            <option value="ALL">All</option>
          </select>
          <div
            style="
              display: flex;
              gap: 0.3rem;
              align-items: center;
              margin-left: 0.5rem;
            "
          >
            <button id="prevPageBtn" class="page-btn" onclick="prevPage()">
              &laquo; Prev
            </button>
            <span
              id="pageIndicator"
              style="
                font-size: 0.85rem;
                font-weight: 600;
                min-width: 85px;
                text-align: center;
              "
              >Page 1 of 1</span
            >
            <button id="nextPageBtn" class="page-btn" onclick="nextPage()">
              Next &raquo;
            </button>
          </div>
        </div>
      </div>

      <div class="table-container">
        <table id="policyTable">
          <thead>
            <tr>
              <th onclick="sortTable(0)">Type</th>
              <th onclick="sortTable(1)">Document Title</th>
              <th onclick="sortTable(2)">Sector</th>
              <th onclick="sortTable(3)">Issuing Authority</th>
              <th onclick="sortTable(4)">Date / Year</th>
              <th class="no-print">Actions & Intelligence</th>
            </tr>
          </thead>
          <tbody id="policyTableBody"></tbody>
        </table>
      </div>
      <!-- Legislative Timeline Section (inside Stockroom) -->
      <div
        style="
          margin-top: 3rem;
          padding-top: 2rem;
          border-top: 2px solid var(--border-color);
        "
      >
        <h2
          data-editable="true"
          style="color: #1f4e78; margin-bottom: 0.5rem; font-size: 1.4rem"
        >
          ⚖️ Provincial Legislative Evolution Timeline
        </h2>
        <p
          style="
            color: var(--muted-color);
            font-size: 0.93rem;
            margin-bottom: 1.5rem;
          "
        >
          Chronological record of legislative enactments from 2008 to 2022
          catalogued in the CPPR Stockroom.
        </p>
        <h2 style="color: #1f4e78; margin-bottom: 1rem">
          Provincial Legislative Evolution Timeline (2008 – 2022)
        </h2>
        <div class="timeline-container">
          <div class="timeline-card" data-year="2008">
            <div class="timeline-year">2008</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (6 Documents)</h4>
              <ul>
                <li>
                  <strong>Act</strong>: The Code of Criminal Procedure
                  (north-West Frontier Province) (amendment) Act, 2008
                </li>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province Finance
                  Act, 2008
                </li>
                <li>
                  <strong>Act</strong>: The Khyber Medical University
                  (amendment) Act, 2008
                </li>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province Local
                  Government (amendment) Act, 2008
                </li>
                <li><em>...and 2 more instruments</em></li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2009">
            <div class="timeline-year">2009</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (18 Documents)</h4>
              <ul>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province Civil
                  Courts (amendment) Act, 2009
                </li>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province
                  Establishment of a Commission on the Status of Women Act, 2009
                </li>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province
                  Ministers (salaries, Allowances and Privileges) (second
                  Amendment) Act, 2009
                </li>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province Civil
                  Servants (amendment) Act, 2009
                </li>
                <li><em>...and 14 more instruments</em></li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2010">
            <div class="timeline-year">2010</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (20 Documents)</h4>
              <ul>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province
                  Establishment of District Development Advisory Committees
                  (amendment) Act, 2010
                </li>
                <li>
                  <strong>Act</strong>: The North-West Frontier Province Medical
                  and Health Institutions and Regulation of Health-Care Services
                  (amendment) Act, 2010
                </li>
                <li>
                  <strong>Act</strong>: The Defence Housing Authority Peshawar
                  (amendment) Act, 2010
                </li>
                <li>
                  <strong>Act</strong>: The Khyber Pakhtunkhwa Chashma Right
                  Bank Canal (lift-Cum-Gravity) Project (control and Prevention
                  of Speculation in Land) Act, 2010
                </li>
                <li><em>...and 16 more instruments</em></li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2011">
            <div class="timeline-year">2011</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (18 Documents)</h4>
              <ul>
                <li>
                  <strong>Act</strong>: The Gomal University (amendment) Act,
                  2011
                </li>
                <li>
                  <strong>Act</strong>: The Iqra National University Act, 2011
                </li>
                <li>
                  <strong>Act</strong>: The Khyber Pakhtunkhwa Appointment,
                  Deputation, Posting and Transfer of Teachers, Lecturers,
                  Instructors and Doctors Regulatory Act, 2011
                </li>
                <li>
                  <strong>Act</strong>: The Khyber Pakhtunkhwa Appointment of
                  Certain Lecturers Act, 2011
                </li>
                <li><em>...and 14 more instruments</em></li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2012">
            <div class="timeline-year">2012</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (15 Documents)</h4>
              <ul>
                <li>
                  <strong>Act</strong>: The Khyber Pakhtunkhwa Apprenticeship
                  (amendment) Act, 2012
                </li>
                <li>
                  <strong>Act</strong>: The Khyber Pakhtunkhwa Borstal
                  Institutions Act, 2012
                </li>
                <li>
                  <strong>Act</strong>: The Khyber Pakhtunkhwa Cessation of
                  Payment of Arrears on Advance Increments on Higher Educational
                  Qualification Act, 2012
                </li>
                <li>
                  <strong>Act</strong>: The Khyber Pakhtunkhwa Disabled Persons
                  (employment and Rehabilitation) (amendment) Act, 2012
                </li>
                <li><em>...and 11 more instruments</em></li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2013">
            <div class="timeline-year">2013</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (2 Documents)</h4>
              <ul>
                <li>
                  <strong>Notification / Guidelines</strong>: General Powers and
                  Standard Procedures for Guidance of Local Governments
                  Notification
                </li>
                <li>
                  <strong>Guidelines</strong>: Guidelines for Transition and
                  Succession of Local Governments Under Khyber Pakhtunkhwa Local
                  Government Act, 2013
                </li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2015">
            <div class="timeline-year">2015</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (4 Documents)</h4>
              <ul>
                <li>
                  <strong>Policy Schedule</strong>: Representation and
                  Composition Matrix for District, Tehsil, Village and
                  Neighbourhood Councils (annex-C)
                </li>
                <li>
                  <strong>Rules</strong>: The Khyber Pakhtunkhwa Local
                  Government Commission (conduct of Business) Rules, 2015
                </li>
                <li>
                  <strong>By-Laws</strong>: The District Council (procedure and
                  Conduct of Business and Meetings) Model By-Laws, 2015
                </li>
                <li>
                  <strong>By-Laws</strong>: The Tehsil Council (procedure and
                  Conduct of Business and Meetings) Model By-Laws, 2015
                </li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2017">
            <div class="timeline-year">2017</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (3 Documents)</h4>
              <ul>
                <li>
                  <strong>Notification</strong>: Checklist Notification for
                  Local Government & Rural Development Department
                </li>
                <li>
                  <strong>Manual / Guide</strong>: Citizen Engagement in
                  Development Planning Manual for Village and Neighbourhood
                  Councils
                </li>
                <li>
                  <strong>By-Laws</strong>: The Khyber Pakhtunkhwa Model
                  Building By-Laws, 2017
                </li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2019">
            <div class="timeline-year">2019</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (1 Documents)</h4>
              <ul>
                <li>
                  <strong>Rules</strong>: Service Rules of Directorate General
                  Local Government and Rural Development Department
                </li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2020">
            <div class="timeline-year">2020</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (1 Documents)</h4>
              <ul>
                <li>
                  <strong>By-Laws</strong>: Model By-Laws for Fruit and
                  Vegetable Markets (local Council Board)
                </li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2021">
            <div class="timeline-year">2021</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (2 Documents)</h4>
              <ul>
                <li>
                  <strong>Rules of Business</strong>: The Khyber Pakhtunkhwa
                  Tehsil Local Government Rules of Business, 2021
                </li>
                <li>
                  <strong>Rules of Business</strong>: The Khyber Pakhtunkhwa
                  Village and Neighbourhood Councils Rules of Business, 2021
                </li>
              </ul>
            </div>
          </div>
          <div class="timeline-card" data-year="2022">
            <div class="timeline-year">2022</div>
            <div class="timeline-content">
              <h4>Legislative Enactments (1 Documents)</h4>
              <ul>
                <li>
                  <strong>Rules of Business</strong>: The Khyber Pakhtunkhwa
                  City and Tehsil Local Government Rules of Business, 2022
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- Departmental Directory Section (inside Stockroom) -->
      <div
        style="
          margin-top: 3rem;
          padding-top: 2rem;
          border-top: 2px solid var(--border-color);
        "
      >
        <h2
          data-editable="true"
          style="color: #1f4e78; margin-bottom: 0.5rem; font-size: 1.4rem"
        >
          🏛️ Provincial Enforcing Departmental Directory
        </h2>
        <p
          style="
            color: var(--muted-color);
            font-size: 0.93rem;
            margin-bottom: 1.5rem;
          "
        >
          Directory of government departments and authorities whose legal
          instruments are catalogued in the CPPR Stockroom.
        </p>
        <h2 style="color: #1f4e78; margin-bottom: 1rem">
          Provincial Enforcing Departmental Directory
        </h2>
        <div class="dept-grid">
          <div class="dept-card">
            <h3>Provincial Assembly of Khyber Pakhtunkhwa</h3>
            <div class="dept-count">37 Assigned Legal Instruments</div>
            <ul class="dept-list">
              <li>
                <span class="badge badge-sops">Policy Schedule</span>
                Representation and Composition Matrix for District, Tehsil,
                Village and Neighbourhood Councils (annex-C)
              </li>
              <li>
                <span class="badge badge-sops">Act</span> The Gomal University
                (amendment) Act, 2011
              </li>
              <li>
                <span class="badge badge-sops">Act</span> The Khyber Pakhtunkhwa
                Appointment, Deputation, Posting and Transfer of Teachers,
                Lecturers, Instructors and Doctors Regulatory Act, 2011
              </li>
              <li><em>+34 additional instruments</em></li>
            </ul>
          </div>
          <div class="dept-card">
            <h3>Provincial Assembly of North-West Frontier Province</h3>
            <div class="dept-count">24 Assigned Legal Instruments</div>
            <ul class="dept-list">
              <li>
                <span class="badge badge-sops">Act</span> The North-West
                Frontier Province Civil Courts (amendment) Act, 2009
              </li>
              <li>
                <span class="badge badge-sops">Act</span> The Code of Criminal
                Procedure (north-West Frontier Province) (amendment) Act, 2008
              </li>
              <li>
                <span class="badge badge-sops">Act</span> The North-West
                Frontier Province Establishment of a Commission on the Status of
                Women Act, 2009
              </li>
              <li><em>+21 additional instruments</em></li>
            </ul>
          </div>
          <div class="dept-card">
            <h3>
              Local Government, Elections and Rural Development Department,
              Government of Khyber Pakhtunkhwa
            </h3>
            <div class="dept-count">22 Assigned Legal Instruments</div>
            <ul class="dept-list">
              <li>
                <span class="badge badge-sops">Notification</span> Checklist
                Notification for Local Government & Rural Development Department
              </li>
              <li>
                <span class="badge badge-sops">Manual / Guide</span> Citizen
                Engagement in Development Planning Manual for Village and
                Neighbourhood Councils
              </li>
              <li>
                <span class="badge badge-sops">Act</span> The North-West
                Frontier Province Establishment of District Development Advisory
                Committees (amendment) Act, 2010
              </li>
              <li><em>+19 additional instruments</em></li>
            </ul>
          </div>
          <div class="dept-card">
            <h3>Senate of Pakistan</h3>
            <div class="dept-count">6 Assigned Legal Instruments</div>
            <ul class="dept-list">
              <li>
                <span class="badge badge-sops">Act</span> The Islamia College
                Peshawar Act, 2009
              </li>
              <li>
                <span class="badge badge-sops">Act</span> The Abasyn University
                Act, 2009
              </li>
              <li>
                <span class="badge badge-sops">Act</span> The Abdul Wali Khan
                University Mardan Act, 2009
              </li>
              <li><em>+3 additional instruments</em></li>
            </ul>
          </div>
          <div class="dept-card">
            <h3>
              Law, Parliamentary Affairs and Human Rights Department, Government
              of Khyber Pakhtunkhwa
            </h3>
            <div class="dept-count">2 Assigned Legal Instruments</div>
            <ul class="dept-list">
              <li>
                <span class="badge badge-sops">Rules of Business</span> The
                Khyber Pakhtunkhwa Tehsil Local Government Rules of Business,
                2021
              </li>
              <li>
                <span class="badge badge-sops">Rules of Business</span> The
                Khyber Pakhtunkhwa Village and Neighbourhood Councils Rules of
                Business, 2021
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB 3: LEGISLATIVE TIMELINE -->
    <!-- TAB 6: CONTACT & ABOUT CPPR -->
    <div id="tabContact" class="tab-content">
      <div style="margin-bottom: 1.5rem">
        <h2 style="color: #1f4e78; font-size: 1.5rem; margin-bottom: 0.5rem">
          Contact & About CPPR
        </h2>
        <p style="color: var(--muted-color); font-size: 1rem">
          Centre for Public Policy Research (CPPR) — Institute of Management
          Sciences (IMSciences), Peshawar
        </p>
      </div>

      <div class="about-section-grid">
        <div class="about-card">
          <h3>📍 Address & Contact</h3>
          <p data-editable="true">
            <strong>Centre for Public Policy Research (CPPR)</strong>
          </p>
          <p>Institute of Management Sciences (IMSciences)</p>
          <p>
            1-A, Sector E-5, Phase 7, Hayatabad, Peshawar, Khyber Pakhtunkhwa,
            Pakistan
          </p>
          <p style="margin-top: 1rem">
            <strong>🌐 Web Platform:</strong>
            <a
              href="https://affanaamin.github.io/cppr-stockroom/"
              target="_blank"
              style="color: #3b82f6; font-weight: 600"
              >affanaamin.github.io/cppr-stockroom</a
            >
          </p>
        </div>

        <div class="about-card">
          <h3>✉️ Policy Inquiries & Research Desk</h3>
          <p
            style="
              margin-bottom: 1rem;
              color: var(--muted-color);
              font-size: 0.95rem;
            "
          >
            Have questions regarding public policy research, baseline surveys,
            third-party evaluations, or policy stockroom access? Send a note
            directly to CPPR:
          </p>
          <div id="inquiryFormContainer">
            <div id="inquiryFormContainer">
            <form
              id="inquiryForm"
              onsubmit="submitInquiry(event)"
              style="display: flex; flex-direction: column; gap: 0.75rem"
            >
              <input
                type="text"
                id="inqName"
                placeholder="Your Name"
                required
                style="
                  padding: 0.65rem;
                  border-radius: 6px;
                  border: 1px solid var(--border-color);
                  background: var(--input-bg);
                  color: var(--text-color);
                "
              />
              <input
                type="email"
                id="inqEmail"
                placeholder="Your Email / Organization"
                required
                style="
                  padding: 0.65rem;
                  border-radius: 6px;
                  border: 1px solid var(--border-color);
                  background: var(--input-bg);
                  color: var(--text-color);
                "
              />
              <textarea
                id="inqMsg"
                placeholder="Your Policy Stockroom or Research Inquiry..."
                rows="3"
                required
                style="
                  padding: 0.65rem;
                  border-radius: 6px;
                  border: 1px solid var(--border-color);
                  background: var(--input-bg);
                  color: var(--text-color);
                "
              ></textarea>
              <button
                type="submit"
                id="inqSubmitBtn"
                style="
                  background: #1f4e78;
                  color: white;
                  padding: 0.65rem 1.2rem;
                  border-radius: 6px;
                  border: none;
                  font-weight: 600;
                  font-size: 0.9rem;
                  cursor: pointer;
                "
              >
                Send Inquiry Directly to CPPR
              </button>
            </form>
          </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer with Admin Access Button -->
    <footer style="text-align: center; margin-top: 3rem; padding: 2rem 0 1rem; border-top: 1px solid var(--border-color); color: var(--muted-color); font-size: 0.85rem; display: flex; flex-direction: column; align-items: center; gap: 0.6rem;">
      <div>Centre for Public Policy Research (CPPR) &middot; IMSciences Peshawar</div>
      <button class="tab-btn" onclick="openAdminLogin()" style="font-size: 0.78rem; padding: 0.35rem 0.85rem; background: transparent; border: 1px solid var(--border-color); color: var(--muted-color); border-radius: 8px;">
        🔐 Admin Access
      </button>
    </footer>

    <!-- PDF Modal Overlay -->
    <div id="pdfModal" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <h3 id="modalTitle">PDF Document Preview</h3>
          <div class="modal-actions">
            <a
              id="modalLocalBtn"
              href="#"
              target="_blank"
              class="btn-sm btn-pdf"
              >Open Local PDF</a
            >
            <a
              id="modalDriveBtn"
              href="#"
              target="_blank"
              class="btn-sm btn-drive"
              >Open on Drive</a
            >
            <button class="close-btn" onclick="closePreview()">&times;</button>
          </div>
        </div>
        <div class="modal-body">
          <iframe id="pdfFrame" src="" title="PDF Document Preview" loading="lazy"></iframe>
        </div>
      </div>
    </div>

    <!-- Policy Brief Modal Overlay -->
    <div id="briefModal" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <h3>Executive Policy Brief Note</h3>
          <div class="modal-actions">
            <button class="close-btn" onclick="closeBrief()">&times;</button>
          </div>
        </div>
        <div class="modal-body" style="background: #f1f5f9">
          <div class="brief-paper">
            <h2 id="briefTitle">Official Policy Document Brief</h2>
            <div class="brief-grid">
              <div class="brief-field">
                <strong>Document Type</strong><span id="briefType"></span>
              </div>
              <div class="brief-field">
                <strong>Policy Sector</strong><span id="briefSector"></span>
              </div>
              <div class="brief-field">
                <strong>Issuing Authority</strong><span id="briefAuth"></span>
              </div>
              <div class="brief-field">
                <strong>Enactment Date</strong><span id="briefDate"></span>
              </div>
            </div>
            <h3>Executive Objective & Summary</h3>
            <p
              id="briefSummary"
              style="margin-top: 0.5rem; line-height: 1.7; color: #334155"
            ></p>
          </div>
        </div>
      </div>
    </div>

    <div
      style="
        background: var(--hover-bg);
        border-left: 4px solid #1f4e78;
        padding: 0.9rem 1.1rem;
        border-radius: 6px;
        margin-top: 1.5rem;
      "
    >
      <strong style="color: #1f4e78; display: block; margin-bottom: 0.2rem"
        >🏛️ Institutional Reference</strong
      >
      <span style="font-size: 0.88rem; color: var(--muted-color)"
        >Centre for Public Policy Research (CPPR), Institute of Management
        Sciences (IMSciences), Peshawar.</span
      >
    </div>

    <!-- CPPR Project Details Modal Overlay -->
    <div id="projectModal" class="modal">
      <div
        class="modal-content"
        style="max-width: 900px; height: 85%; max-height: 700px"
      >
        <div class="modal-header">
          <h3 id="projModalHeaderTitle">CPPR Research Project Details</h3>
          <div class="modal-actions">
            <button class="close-btn" onclick="closeProjectModal()">
              &times;
            </button>
          </div>
        </div>
        <div
          class="modal-body"
          style="
            background: var(--bg-color);
            padding: 1.5rem 2rem;
            overflow-y: auto;
          "
        >
          <div
            class="brief-paper"
            style="
              margin: 0 auto;
              max-width: 820px;
              box-shadow: var(--shadow-md);
              background: var(--card-bg);
              color: var(--text-color);
              padding: 2rem;
              border-radius: 12px;
              border: 1px solid var(--border-color);
            "
          >
            <div
              style="
                display: flex;
                gap: 0.5rem;
                flex-wrap: wrap;
                margin-bottom: 0.8rem;
              "
            >
              <span id="projModalBadge" class="badge badge-act"></span>
              <span id="projModalSector" class="badge badge-rules"></span>
              <span
                id="projModalPartner"
                class="badge badge-sops"
                style="background: #e0f2fe; color: #0369a1"
              ></span>
            </div>
            <h2
              id="projModalTitle"
              style="
                color: #1f4e78;
                border-bottom: 2px solid #1f4e78;
                padding-bottom: 0.75rem;
                margin-bottom: 1.2rem;
                font-size: 1.4rem;
                line-height: 1.4;
              "
            ></h2>
            <h4
              style="color: #1f4e78; font-size: 1.05rem; margin-bottom: 0.8rem"
            >
              🔍 Project Overview &amp; Scope
            </h4>
            <div
              id="projModalOverview"
              style="
                line-height: 1.75;
                font-size: 0.95rem;
                color: var(--text-color);
                margin-bottom: 1.5rem;
                display: flex;
                flex-direction: column;
                gap: 1rem;
              "
            ></div>
            <div
              style="
                background: var(--hover-bg);
                border-left: 4px solid #1f4e78;
                padding: 0.9rem 1.1rem;
                border-radius: 6px;
                margin-top: 1.5rem;
              "
            >
              <strong
                style="color: #1f4e78; display: block; margin-bottom: 0.2rem"
                >🏛️ Institutional Reference</strong
              >
              <span style="font-size: 0.88rem; color: var(--muted-color)"
                >Centre for Public Policy Research (CPPR), Institute of
                Management Sciences (IMSciences), Peshawar.</span
              >
            </div>
          </div>
        </div>
      </div>
    </div>

    
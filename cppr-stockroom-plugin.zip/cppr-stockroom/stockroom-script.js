
      function debounce(func, wait) {
        let timeout;
        return function(...args) {
          clearTimeout(timeout);
          timeout = setTimeout(() => func.apply(this, args), wait);
        };
      }
      function switchTab(tabId) {
        document
          .querySelectorAll(".tab-content")
          .forEach((el) => el.classList.remove("active"));
        document
          .querySelectorAll(".tab-btn")
          .forEach((el) => el.classList.remove("active"));
        const targetContent = document.getElementById(tabId);
        if (targetContent) targetContent.classList.add("active");
        const btns = document.querySelectorAll(".tab-btn");
        btns.forEach((btn) => {
          if (
            btn.getAttribute("onclick") &&
            btn.getAttribute("onclick").includes(tabId)
          ) {
            btn.classList.add("active");
          }
        });
        window.scrollTo({ top: 0, behavior: "smooth" });
      }

      function toggleDarkMode() {
        document.body.classList.toggle("dark-mode");
        const isDark = document.body.classList.contains("dark-mode");
        document.getElementById("themeLabel").innerText = isDark
          ? "Light Mode"
          : "Dark Mode";
        localStorage.setItem("cppr_theme", isDark ? "dark" : "light");
      }

      if (localStorage.getItem("cppr_theme") === "dark") {
        document.body.classList.add("dark-mode");
        document.addEventListener("DOMContentLoaded", () => {
          const label = document.getElementById("themeLabel");
          if (label) label.innerText = "Light Mode";
        });
      }

      let currentPage = 1;
      let pageSize = 15;
      let filteredDocs = [];
      let allDocCache = [];

      var sectorBadgeMap = {
        Governance: "sec-gov",
        Health: "sec-health",
        "Higher Education": "sec-edu",
        "Law & Justice": "sec-law",
        "Finance & Taxation": "sec-fin",
        "Social Welfare & Human Rights": "sec-wel",
        "Public Safety & Security": "sec-safe",
        "Transport & Infrastructure": "sec-trans",
        "Industries & Commerce": "sec-ind",
        "Housing & Land Revenue": "sec-house",
      };

      var typeBadgeMap = {
        Act: "badge-act",
        Rules: "badge-rules",
        "Rules of Business": "badge-rules",
        "By-Laws": "badge-rules",
        Notification: "badge-sops",
        SOPs: "badge-sops",
        "Policy Schedule": "badge-sops",
        "Research Study": "badge-act",
      };

      function initTableCache() {
        const rawData = window.CPPR_DOCUMENTS || [];
        allDocCache = rawData.map((doc) => {
          const searchableText = (
            (doc.title || "") + " " +
            (doc.authority || "") + " " +
            (doc.ocr || "")
          ).toLowerCase();
          return {
            doc: doc,
            category: doc.category || "",
            sector: doc.sector || "",
            year: doc.year || "",
            searchableText: searchableText,
            titleLower: (doc.title || "").toLowerCase(),
            authLower: (doc.authority || "").toLowerCase(),
            dateLower: (doc.date || "").toLowerCase()
          };
        });
      }

      function createRowHTML(doc) {
        var secClass = sectorBadgeMap[doc.sector] || "sec-gen";
        var typeClass = typeBadgeMap[doc.category] || "badge-sops";
        var driveHtml = "";
        if (doc.driveUrl) {
          var cleanDrive = doc.driveUrl.replace(/'/g, "\\'");
          var cleanTitle = (doc.title || "").replace(/'/g, "\\'");
          driveHtml =
            '<button class="btn-sm btn-preview" onclick="openPreview(\'' + cleanTitle + '\', \'\', \'' + cleanDrive + '\')">Preview</button>' +
            '<a href="' + doc.driveUrl + '" target="_blank" class="btn-sm btn-drive">Drive</a>';
        }
        var cleanSummary = (doc.summary || "").replace(/'/g, "\\'");
        var cleanAuth = (doc.authority || "").replace(/'/g, "\\'");
        var cleanTitleAttr = (doc.title || "").replace(/"/g, "&quot;");

        return '<tr data-category="' + (doc.category || "") + '" data-sector="' + (doc.sector || "") + '" data-year="' + (doc.year || "") + '">' +
          '<td><span class="badge ' + typeClass + '">' + (doc.category || "Doc") + '</span></td>' +
          '<td class="col-title" data-raw="' + cleanTitleAttr + '"><strong>' + (doc.title || "") + '</strong></td>' +
          '<td><span class="badge ' + secClass + '">' + (doc.sector || "") + '</span></td>' +
          '<td class="col-auth">' + (doc.authority || "") + '</td>' +
          '<td>' + (doc.date || "") + '</td>' +
          '<td class="no-print"><div class="action-btns">' +
          driveHtml +
          '<button class="btn-sm btn-brief" onclick="openBrief(\'' + (doc.title || "").replace(/'/g, "\\'") + '\', \'' + (doc.category || "") + '\', \'' + (doc.sector || "") + '\', \'' + cleanAuth + '\', \'' + (doc.date || "") + '\', \'' + cleanSummary + '\')">Brief</button>' +
          '</div><span class="admin-row-actions"><button class="admin-row-btn del" onclick="deleteTableRow(this)" title="Delete row">✕</button></span></td>' +
          '</tr>';
      }

      function runFilters() {
        if (!allDocCache.length) {
          initTableCache();
        }
        const query = (document.getElementById("searchInput").value || "")
          .toLowerCase()
          .trim();
        const sector = document.getElementById("sectorFilter").value;
        const type = document.getElementById("typeFilter").value;
        const year = document.getElementById("yearFilter").value;
        
        filteredDocs = [];
        allDocCache.forEach((item) => {
          const matchesSearch = !query || item.searchableText.includes(query);
          const matchesSector = sector === "ALL" || item.sector === sector;
          const matchesType = type === "ALL" || item.category === type;
          const matchesYear = year === "ALL" || item.year === year;
          
          if (matchesSearch && matchesSector && matchesType && matchesYear) {
            filteredDocs.push(item);
          }
        });

        const counterText = document.getElementById("counterText");
        if (counterText) {
          counterText.innerText = "Showing " + filteredDocs.length + " of " + allDocCache.length + " Documents";
        }
        currentPage = 1;
        renderPagination();
      }

      const debouncedRunFilters = debounce(runFilters, 250);

      function applyFilters() {
        debouncedRunFilters();
      }

      function renderPagination() {
        const total = filteredDocs.length;
        const selectVal = document.getElementById("pageSizeSelect").value;
        pageSize = selectVal === "ALL" ? total : parseInt(selectVal, 10);
        const totalPages = pageSize > 0 ? Math.ceil(total / pageSize) : 1;
        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;
        const startIdx = (currentPage - 1) * pageSize;
        const endIdx =
          pageSize === total || selectVal === "ALL"
            ? total
            : Math.min(startIdx + pageSize, total);
        
        const pageItems = filteredDocs.slice(startIdx, endIdx);
        const tbody = document.getElementById("policyTableBody");
        if (tbody) {
          tbody.innerHTML = pageItems.map((item) => createRowHTML(item.doc)).join("");
        }

        const pageIndicator = document.getElementById("pageIndicator");
        if (pageIndicator)
          pageIndicator.innerText =
            total === 0
              ? "Page 0 of 0"
              : "Page " + currentPage + " of " + (totalPages || 1);
        const prevBtn = document.getElementById("prevPageBtn");
        const nextBtn = document.getElementById("nextPageBtn");
        if (prevBtn) prevBtn.disabled = currentPage <= 1;
        if (nextBtn)
          nextBtn.disabled = currentPage >= totalPages || totalPages === 0;
      }

      function prevPage() {
        if (currentPage > 1) {
          currentPage--;
          renderPagination();
        }
      }
      function nextPage() {
        const totalPages = Math.ceil(filteredDocs.length / pageSize);
        if (currentPage < totalPages) {
          currentPage++;
          renderPagination();
        }
      }
      function changePageSize() {
        currentPage = 1;
        renderPagination();
      }

      function resetFilters() {
        document.getElementById("searchInput").value = "";
        document.getElementById("sectorFilter").value = "ALL";
        document.getElementById("typeFilter").value = "ALL";
        document.getElementById("yearFilter").value = "ALL";
        currentPage = 1;
        runFilters();
      }

      function filterStockroomBySector(secName) {
        switchTab("tabStockroom");
        document.getElementById("sectorFilter").value = secName;
        applyFilters();
      }

      let sortAsc = true;
      function sortTable(colIdx) {
        const table = document.getElementById("policyTable");
        const thead = table.querySelector("thead");
        if (thead) {
          const headers = thead.querySelectorAll("th");
          headers.forEach((th, idx) => {
            th.innerText = th.innerText.replace(/ ▲| ▼/g, "");
            if (idx === colIdx) {
              th.innerText += sortAsc ? " ▲" : " ▼";
            }
          });
        }
        if (!allDocCache.length) initTableCache();
        
        allDocCache.sort((a, b) => {
          let valA = "", valB = "";
          if (colIdx === 0) { valA = a.category; valB = b.category; }
          else if (colIdx === 1) { valA = a.titleLower; valB = b.titleLower; }
          else if (colIdx === 2) { valA = a.sector; valB = b.sector; }
          else if (colIdx === 3) { valA = a.authLower; valB = b.authLower; }
          else if (colIdx === 4) { valA = a.dateLower; valB = b.dateLower; }
          return sortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
        });
        sortAsc = !sortAsc;
        runFilters();
      }

      function openPreview(title, localUrl, driveUrl) {
        document.getElementById("modalTitle").innerText = title;
        document.getElementById("modalLocalBtn").href = localUrl;
        document.getElementById("modalDriveBtn").href = driveUrl;
        let embedUrl = driveUrl;
        if (driveUrl && driveUrl.includes("/file/d/")) {
          embedUrl = driveUrl
            .replace("/view?usp=sharing", "/preview")
            .replace("/view", "/preview");
        }
        document.getElementById("pdfFrame").src = embedUrl;
        document.getElementById("pdfModal").style.display = "flex";
      }
      function closePreview() {
        document.getElementById("pdfModal").style.display = "none";
        document.getElementById("pdfFrame").src = "";
      }

      function openBrief(title, type, sector, auth, date, summary) {
        document.getElementById("briefTitle").innerText = title;
        document.getElementById("briefType").innerText = type;
        document.getElementById("briefSector").innerText = sector;
        document.getElementById("briefAuth").innerText = auth;
        document.getElementById("briefDate").innerText = date;
        document.getElementById("briefSummary").innerText = summary;
        document.getElementById("briefModal").style.display = "flex";
      }
      function closeBrief() {
        document.getElementById("briefModal").style.display = "none";
      }

      // ── CPPR Projects Dataset ──────────────────────────────
      var cpprProjectsData = [
        {
          id: "proj-1",
          title:
            "Promoting Equity Budgeting in Elementary & Secondary Education in Khyber Pakhtunkhwa",
          shortTitle: "Equity Budgeting in KP Education",
          sector: "Higher Education",
          badge: "Baseline Research",
          partner: "Article 25A & SDG 4 Framework",
          summary:
            "Examines public education sector budgeting and resource allocation in KP to strengthen equity considerations for marginalized groups under Article 25A and SDG 4.",
          overview: [
            "This project aims to strengthen the integration of equity considerations into public education financing and budgeting processes in the province. The initiative contributes to the realization of Article 25A of the Constitution of Pakistan and Sustainable Development Goal 4, which emphasize inclusive and equitable access to quality education for all children. By examining how education sector budgets address the needs of marginalized groups, the project seeks to support more inclusive and evidence-based policy and planning processes in Khyber Pakhtunkhwa.",
            "The project undertook a comprehensive analysis of education sector budgeting and resource allocation in the province, focusing on identifying equity gaps that may affect access to quality education. The study combined secondary data analysis with field-based research to better understand how public resources are distributed and how budgeting decisions influence educational opportunities for different population groups.",
            "By producing policy-relevant research and analysis, the project aims to support more equitable budgeting practices within the education sector and inform ongoing policy discussions on inclusive education financing.",
          ],
        },
        {
          id: "proj-2",
          title:
            "Empowering Women Through Digital Innovation (Upskill KP Women Initiative)",
          shortTitle: "Upskill KP Women Initiative",
          sector: "Social Welfare & Human Rights",
          badge: "Technical Initiative",
          partner: "Swat, Chitral, Charsadda & Nowshera Cohorts",
          summary:
            "Promotes inclusive economic participation by equipping women in Swat, Chitral, Charsadda, and Nowshera with digital, entrepreneurial, and green journalism skills across two intensive training cohorts.",
          overview: [
            "The Upskill KP Women Initiative was launched to promote inclusive economic participation by equipping women in Khyber Pakhtunkhwa with practical digital and entrepreneurial skills. The program specifically targeted women from Swat, Chitral, Charsadda, and Nowshera, addressing the significant gender gap in Pakistan’s technology and digital sectors where women and marginalized groups remain underrepresented.",
            "The program began with a province-wide outreach campaign followed by a competitive multi-stage selection process. The curriculum consisted of twelve modules covering e-commerce, social media marketing, digital design, video animation, accounting for startups, data analytics, and the art of pitching, organized into two cohorts.",
            "Beyond technical training, the initiative created opportunities for networking, mentorship, and exposure to the entrepreneurial ecosystem. Participants engaged with trainers and startup founders, and visited the National Incubation Centre to gain firsthand insights into the startup environment.",
          ],
        },
        {
          id: "proj-3",
          title:
            "Strengthening Public Policy and Social Protection Reforms Unit (PP-SPRU)",
          shortTitle: "PP-SPRU Social Protection Reforms",
          sector: "Governance",
          badge: "Policy Reform",
          partner: "CPPR + P&D Dept KP + GIZ ASP Project",
          summary:
            "Collaborative initiative with P&D Department KP and GIZ establishing institutional, legal, and technical foundations for an integrated social protection system and unified beneficiary registry in KP.",
          overview: [
            "The project is implemented by CPPR at the Institute of Management Sciences in collaboration with the PP-SPRU of the Sustainable Development Unit, Planning and Development Department, Government of Khyber Pakhtunkhwa. With support from the GIZ Adaptive Social Protection project, the initiative aims to strengthen PP-SPRU as the provincial focal agency for social protection.",
            "The project is structured around six interconnected components including development of a legal framework, governance and coordination mechanisms, creation of an Integrated Social Protection Information System anchored by a unified beneficiary registry, and a results-based M&E framework covering multiple social protection programs.",
            "Through these activities, the project seeks to address fragmentation in social protection delivery and promote greater coordination, transparency, and efficiency. By integrating data systems and strengthening institutional capacity, the initiative enables evidence-based decision-making and improves the targeting and effectiveness of social protection interventions.",
          ],
        },
        {
          id: "proj-4",
          title:
            "Health Facility Digital Readiness Assessment under the Social Health Protection Initiative (SHPI) Phase-III",
          shortTitle: "SHPI Phase-III Digital Health Assessment",
          sector: "Health",
          badge: "Field Assessment",
          partner: "SHPI Phase-III (149 Facilities in 4 Districts)",
          summary:
            "Census-based readiness evaluation across 149 public and private health facilities in 4 districts of KP, assessing IT infrastructure, DHIS II, digital referral readiness, and workforce digital literacy.",
          overview: [
            "This project conducted a Digital Health Facility Readiness Assessment to support the implementation of SHPI Phase III, focusing on the digital transformation of healthcare services in Khyber Pakhtunkhwa. The assessment evaluated the readiness of health facilities to adopt digital health solutions across four districts: Mardan, Kohat, Malakand, and Chitral, covering 149 public and private health facilities.",
            "The study employed a census-based research design using digital data collection tools to gather facility-level information on power supply, internet connectivity, IT infrastructure, staffing capacity, and existing data management systems. Most facilities were found to rely heavily on paper-based processes for patient registration and referrals.",
            "Despite infrastructure constraints, the assessment found strong willingness among health facility staff to adopt digital tools and identified several institutional entry points for digital transformation, providing a baseline for the phased rollout of digital health interventions under SHPI Phase III.",
          ],
        },
        {
          id: "proj-5",
          title:
            "Public Perception Tracker Survey on local safety and security in Khyber Pakhtunkhwa and Balochistan",
          shortTitle: "UNDP Security & Justice Perception Tracker",
          sector: "Public Safety & Security",
          badge: "Perception Survey",
          partner: "UNDP Pakistan Rule of Law Programme (3,130 Interviews)",
          summary:
            "Large-scale perception survey across 12 districts in KP & Balochistan evaluating public access, trust, and satisfaction with formal (police/courts) and informal (jirgas/ADR) security and justice service providers.",
          overview: [
            "The project was conducted in collaboration with UNDP Pakistan to assess citizens’ experiences and perceptions of security and justice institutions in Khyber Pakhtunkhwa and Balochistan, providing a baseline for the UNDP Pakistan Rule of Law Programme.",
            "The study employed a household survey methodology, conducting 3,130 face-to-face interviews across 12 districts in the two provinces, including both urban and rural areas, measuring levels of access, satisfaction, and preferences for formal and informal dispute resolution mechanisms.",
            "The findings highlight the continued importance of both formal institutions such as courts and police, and informal mechanisms including local jirgas and community-based dispute resolution systems. The survey provides valuable insights for policymakers seeking to strengthen justice systems and improve equitable access to security services.",
          ],
        },
        {
          id: "proj-6",
          title: "DAI - LRMA-II (Land Registration in Merged Areas - II)",
          shortTitle: "Land Registration in Merged Areas (LRMA-II)",
          sector: "Housing & Land Revenue",
          badge: "Empirical Study",
          partner: "DAI LRMA-II (7 Sub-Districts / 764 Households)",
          summary:
            "User feedback evaluation across 7 merged sub-districts assessing land registration digitization, property rights awareness, land dispute mechanisms, and 2023 vs 2024 baseline progress.",
          overview: [
            "The project focuses on assessing user perceptions, access, and awareness related to land registration and administration systems in the merged districts of Khyber Pakhtunkhwa, supporting the LRMA initiative which aims to strengthen land governance through formal registration and digitization.",
            "The study is based on a large-scale user feedback survey across seven sub-districts including Khar-Bajaur, Landi Kotal-Khyber, Dara Adam Khel-Kohat, Hassan Khel-Peshawar, Wazir-Bannu, and Upper and Lower Kurram, conducting 764 household interviews.",
            "The findings indicate improvements in access to land administration services and increasing public confidence in formal land registration. However, the study also highlights persistent challenges including low levels of formal registration and significant gender disparities in land ownership and decision-making.",
          ],
        },
        {
          id: "proj-7",
          title:
            "Making TVET Pro-Poor (Sehat Card Plus Sustainability & Financing)",
          shortTitle: "Making TVET Pro-Poor",
          sector: "Finance & Taxation",
          badge: "Policy Financing Study",
          partner: "KP Social Protection & Sehat Card Plus Initiative",
          summary:
            "Investigates willingness-to-pay (WTP) and co-insurance feasibility for KP’s universal Sehat Card Plus health program to ensure long-term financial sustainability and TVET labor market inclusion.",
          overview: [
            "The project focuses on strengthening evidence for sustainable social protection policies in Khyber Pakhtunkhwa, particularly in the context of health insurance and labour market inclusion. Social protection programs often operate in fragmented institutional arrangements with limited coordination.",
            "A central component examines the Sehat Card Plus (SCP) program, a major social health protection initiative providing free inpatient health insurance coverage to KP residents. Initially launched in 2015 for households below the poverty line, the program has expanded to provide universal health coverage, creating sustainability challenges due to high annual premium costs.",
            "Through survey-based research and policy analysis, the project generates empirical evidence to inform government decision-making on the future financing of the Sehat Card Plus program, assessing the feasibility of introducing a co-insurance model.",
          ],
        },
        {
          id: "proj-8",
          title:
            "Mapping of Brick Kilns and profiling of workers in district Peshawar and Nowshera",
          shortTitle: "Brick Kilns Worker Profiling & Labor Rights Study",
          sector: "Industries & Commerce",
          badge: "Labor Rights & Field Survey",
          partner: "ILO Decent Work Country Programme (2023-2027)",
          summary:
            "Mixed-methods study analyzing working conditions, bonded labor, child labor, gender wage discrimination, and KP Brick Kilns Act (2024) compliance in Peshawar and Nowshera.",
          overview: [
            "This project examines the socio-economic conditions, labor practices, and institutional challenges within the brick kiln sector in Peshawar and Nowshera. The study aims to generate evidence on working conditions, labor rights, and access to social protection among brick kiln workers, who often face bonded labor, exploitative wages, and hazardous occupational environments.",
            "Using a mixed-methods approach combining desk review, household-level survey data, and key informant interviews, the research explores critical issues including child labor, occupational health and safety conditions, wage practices, and barriers to social protection coverage, with special attention to gender dynamics.",
            "The findings highlight significant gaps between existing labor regulations and implementation. The study provides evidence-based recommendations aligned with the ILO Decent Work Country Programme (2023-2027), emphasizing regulatory enforcement, improved occupational safety standards, and stronger institutional coordination.",
          ],
        },
        {
          id: "proj-9",
          title:
            "Research on Market Dynamics and Livelihood Interventions: Analyzing Labor Markets and Value Chains in KPK",
          shortTitle: "Labor Markets & Afghan Refugee Livelihoods",
          sector: "Industries & Commerce",
          badge: "Livelihood & Value Chain Analysis",
          partner: "International Organization for Migration (IOM)",
          summary:
            "Study conducted with IOM analyzing labor market dynamics, Afghan refugee integration, value chain opportunities, and workforce skill alignment across 3 districts of KP.",
          overview: [
            "This study was conducted to assess labor market dynamics and livelihood opportunities in Khyber Pakhtunkhwa, with a particular focus on the integration of Afghan refugees into local economic systems. Implemented with the support of the International Organization for Migration (IOM), the initiative aims to strengthen availability and quality of data on local markets, labor markets, and value chains.",
            "The research employed a mixed-methods approach analyzing labor market trends across agriculture, industry, and services sectors in three districts: Peshawar, Nowshera, and Charsadda. Surveys were conducted with job seekers and employers from both Pakistani and Afghan communities.",
            "Findings highlight a growing preference for employment in the services sector. However, the research identifies significant barriers including skills mismatches, limited work experience, access to finance, and regulatory challenges. Afghan refugees face additional constraints related to documentation and legal limitations.",
          ],
        },
      ];

      function renderResearchProjectsGrid() {
        var grid = document.getElementById("cpprProjectsGrid");
        if (!grid) return;
        grid.innerHTML = cpprProjectsData
          .map(function (p) {
            return (
              '<div class="dept-card" style="display:flex;flex-direction:column;justify-content:space-between;border-top:4px solid #1F4E78;background:var(--card-bg);">' +
              "<div>" +
              '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.5rem;margin-bottom:0.6rem;">' +
              '<span class="badge badge-act" style="font-size:0.72rem;">' +
              p.badge +
              "</span>" +
              '<span class="badge badge-rules" style="font-size:0.72rem;">' +
              p.sector +
              "</span>" +
              "</div>" +
              '<h3 style="font-size:1.05rem;color:#1F4E78;line-height:1.4;margin-bottom:0.5rem;">' +
              p.title +
              "</h3>" +
              '<div style="font-size:0.78rem;color:#0369A1;font-weight:600;margin-bottom:0.6rem;">Partner: ' +
              p.partner +
              "</div>" +
              '<p style="font-size:0.88rem;color:var(--muted-color);line-height:1.55;margin-bottom:1rem;">' +
              p.summary +
              "</p>" +
              "</div>" +
              '<button class="btn-sm btn-preview proj-view-btn" data-projid="' +
              p.id +
              '" style="width:100%;justify-content:center;padding:0.6rem;margin-top:0.5rem;font-weight:600;">View Overview</button>' +
              "</div>"
            );
          })
          .join("");
        grid.addEventListener("click", function (e) {
          var btn = e.target.closest(".proj-view-btn");
          if (btn) openProjectModal(btn.getAttribute("data-projid"));
        });
      }

      function openProjectModal(projId) {
        var p = null;
        for (var i = 0; i < cpprProjectsData.length; i++) {
          if (cpprProjectsData[i].id === projId) {
            p = cpprProjectsData[i];
            break;
          }
        }
        if (!p) {
          console.error("Project not found:", projId);
          return;
        }

        var modal = document.getElementById("projectModal");
        if (!modal) {
          console.error("projectModal element not found in DOM");
          return;
        }

        var el = function (id) {
          return document.getElementById(id);
        };
        if (el("projModalHeaderTitle"))
          el("projModalHeaderTitle").innerText = p.shortTitle || p.title;
        if (el("projModalTitle")) el("projModalTitle").innerText = p.title;
        if (el("projModalBadge")) el("projModalBadge").innerText = p.badge;
        if (el("projModalSector"))
          el("projModalSector").innerText = "Sector: " + p.sector;
        if (el("projModalPartner"))
          el("projModalPartner").innerText = "Partner: " + p.partner;
        if (el("projModalOverview")) {
          el("projModalOverview").innerHTML = p.overview
            .map(function (para) {
              return '<p style="margin:0;line-height:1.75;">' + para + "</p>";
            })
            .join("");
        }
        modal.style.display = "flex";
      }

      function closeProjectModal() {
        var modal = document.getElementById("projectModal");
        if (modal) modal.style.display = "none";
      }

      window.addEventListener("click", function (e) {
        var projModal = document.getElementById("projectModal");
        var pdfModal = document.getElementById("pdfModal");
        var briefModal = document.getElementById("briefModal");
        var adminOverlay = document.getElementById("adminOverlay");
        if (e.target === projModal) closeProjectModal();
        if (e.target === pdfModal) closePreview();
        if (e.target === briefModal) closeBrief();
        if (e.target === adminOverlay) skipAdminLogin();
      });

      window.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
          closeProjectModal();
          closePreview();
          closeBrief();
          skipAdminLogin();
        }
        if ((e.ctrlKey || e.metaKey) && e.key === "k") {
          e.preventDefault();
          const searchInput = document.getElementById("searchInput");
          if (searchInput) searchInput.focus();
        }
      });

      function submitInquiry(e) {
        e.preventDefault();
        var name = document.getElementById("inqName") ? document.getElementById("inqName").value : "";
        var email = document.getElementById("inqEmail") ? document.getElementById("inqEmail").value : "";
        var msg = document.getElementById("inqMsg") ? document.getElementById("inqMsg").value : "";
        var refCode = "CPPR-INQ-" + Math.floor(1000 + Math.random() * 9000);
        var btn = e.target.querySelector("button[type='submit']");
        if (btn) {
          btn.disabled = true;
          btn.innerText = "Sending Inquiry...";
        }

        fetch("https://formsubmit.co/ajax/affanaminbat@gmail.com", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: JSON.stringify({
            _subject: "New Policy Stockroom Inquiry [" + refCode + "]",
            _captcha: "false",
            "Tracking Reference": refCode,
            "Sender Name": name,
            "Sender Email": email,
            "Inquiry Message": msg
          })
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
          var container = document.getElementById("inquiryFormContainer");
          if (container) {
            container.innerHTML =
              '<div style="background:rgba(16,185,129,0.1);border:1px solid #10B981;color:var(--text-color);padding:1.4rem;border-radius:10px;font-size:0.95rem;">' +
              '<h4 style="margin:0 0 0.5rem 0;color:#10B981;font-size:1.1rem;">✉️ Inquiry Emailed Successfully!</h4>' +
              '<p style="margin:0 0 0.4rem 0;"><strong>Tracking Code:</strong> <code>' + refCode + '</code></p>' +
              '<p style="margin:0 0 0.6rem 0;line-height:1.6;">Thank you, <strong>' + name + '</strong>. Your message has been sent directly to <code>affanaminbat@gmail.com</code>.</p>' +
              '<small style="color:var(--muted-color);">Zero popups, zero redirects. We will respond to your email shortly.</small>' +
              '</div>';
          }
        })
        .catch(function(err) {
          console.error("Submission error:", err);
          var container = document.getElementById("inquiryFormContainer");
          if (container) {
            container.innerHTML =
              '<div style="background:rgba(16,185,129,0.1);border:1px solid #10B981;color:var(--text-color);padding:1.4rem;border-radius:10px;font-size:0.95rem;">' +
              '<h4 style="margin:0 0 0.5rem 0;color:#10B981;font-size:1.1rem;">Inquiry Registered!</h4>' +
              '<p style="margin:0 0 0.4rem 0;"><strong>Tracking Reference:</strong> <code>' + refCode + '</code></p>' +
              '<p style="margin:0 0 0.6rem 0;">Thank you, <strong>' + name + '</strong>. Your research note has been registered.</p>' +
              '</div>';
          }
        });
      }

      document.addEventListener("DOMContentLoaded", function () {
        runFilters();
        renderResearchProjectsGrid();
      });

      // ── ADMIN PANEL SYSTEM ─────────────────────────────────
      var ADMIN_PASSWORD = "cppr2024";

      function openAdminLogin() {
        var overlay = document.getElementById("adminOverlay");
        if (overlay) {
          overlay.classList.remove("hidden");
          var input = document.getElementById("adminPassInput");
          if (input) {
            input.value = "";
            input.focus();
          }
        }
      }

      function adminLogin() {
        var input = document.getElementById("adminPassInput");
        var error = document.getElementById("adminLoginError");
        if (input.value === ADMIN_PASSWORD) {
          sessionStorage.setItem("cppr_admin", "true");
          document.getElementById("adminOverlay").classList.add("hidden");
          enableAdminMode();
        } else {
          error.style.display = "block";
          input.value = "";
          input.focus();
          setTimeout(function () {
            error.style.display = "none";
          }, 3000);
        }
      }

      function skipAdminLogin() {
        document.getElementById("adminOverlay").classList.add("hidden");
      }

      function enableAdminMode() {
        document.body.classList.add("admin-mode");
      }

      function adminLogout() {
        document.body.classList.remove("admin-mode");
        sessionStorage.removeItem("cppr_admin");

        // Turn off global edit mode if on
        if (isGlobalEditMode) toggleGlobalEdit();
        var editables = document.querySelectorAll("[contenteditable]");
        for (var i = 0; i < editables.length; i++) {
          editables[i].removeAttribute("contenteditable");
        }
        document.getElementById("adminOverlay").classList.remove("hidden");
        document.getElementById("adminPassInput").value = "";
      }

      // Auto-restore admin session
      if (sessionStorage.getItem("cppr_admin") === "true") {
        document.addEventListener("DOMContentLoaded", function () {
          document.getElementById("adminOverlay").classList.add("hidden");
          enableAdminMode();
        });
      }

      // ── Add Document ────────────────────────────
      function showAddDocModal() {
        document.getElementById("addDocModal").classList.add("visible");
      }
      function hideAddDocModal() {
        document.getElementById("addDocModal").classList.remove("visible");
      }

      var sectorBadgeMap = {
        Governance: "sec-gov",
        Health: "sec-health",
        "Higher Education": "sec-edu",
        "Law & Justice": "sec-law",
        "Finance & Taxation": "sec-fin",
        "Social Welfare & Human Rights": "sec-wel",
        "Public Safety & Security": "sec-safe",
        "Transport & Infrastructure": "sec-trans",
        "Industries & Commerce": "sec-ind",
        "Housing & Land Revenue": "sec-house",
      };

      var typeBadgeMap = {
        Act: "badge-act",
        Rules: "badge-rules",
        "Rules of Business": "badge-rules",
        "By-Laws": "badge-rules",
        Notification: "badge-sops",
        SOPs: "badge-sops",
        "Policy Schedule": "badge-sops",
        "Research Study": "badge-act",
      };

      function addNewDocument() {
        var title = document.getElementById("newDocTitle").value.trim();
        var type = document.getElementById("newDocType").value;
        var sector = document.getElementById("newDocSector").value;
        var auth = document.getElementById("newDocAuth").value.trim();
        var date = document.getElementById("newDocDate").value.trim();
        var drive = document.getElementById("newDocDrive").value.trim();
        var summary = document.getElementById("newDocSummary").value.trim();

        if (!title || !auth || !date || !summary) {
          alert(
            "Please fill in all required fields (Title, Authority, Date, Summary).",
          );
          return;
        }

        var yearMatch = date.match(/\d{4}/);
        var year = yearMatch ? yearMatch[0] : "";
        var secClass = sectorBadgeMap[sector] || "sec-gen";
        var typeClass = typeBadgeMap[type] || "badge-sops";

        var driveHtml = "";
        if (drive) {
          driveHtml =
            '<button class="btn-sm btn-preview" onclick="openPreview(\'' + title.replace(/'/g,"\\'") +
            "', '', '" +
            drive.replace(/'/g, "\\'") +
            "')\">Preview</button>" +
            '<a href="' +
            drive +
            '" target="_blank" class="btn-sm btn-drive">Drive</a>';
        }

        var tr = document.createElement("tr");
        tr.setAttribute("data-category", type);
        tr.setAttribute("data-sector", sector);
        tr.setAttribute("data-year", year);
        tr.setAttribute(
          "data-ocr",
          title.toLowerCase() +
            " " +
            auth.toLowerCase() +
            " " +
            summary.toLowerCase(),
        );
        tr.innerHTML =
          '<td><span class="badge ' +
          typeClass +
          '">' +
          type +
          "</span></td>" +
          '<td class="col-title" contenteditable="true" data-raw="' +
          title.replace(/"/g, "&quot;") +
          '"><strong>' +
          title +
          "</strong></td>" +
          '<td><span class="badge ' +
          secClass +
          '">' +
          sector +
          "</span></td>" +
          '<td class="col-auth" contenteditable="true" data-raw="' +
          auth.replace(/"/g, "&quot;") +
          '">' +
          auth +
          "</td>" +
          "<td>" +
          date +
          "</td>" +
          '<td class="no-print"><div class="action-btns">' +
          driveHtml +
          '<button class="btn-sm btn-brief" onclick="openBrief(\'' + title.replace(/'/g,"\\'") +
          "', '" +
          type +
          "', '" +
          sector +
          "', '" +
          auth.replace(/'/g, "\\'") +
          "', '" +
          date +
          "', '" +
          summary.replace(/'/g, "\\'") +
          "')\">Brief</button>" +
          '</div><span class="admin-row-actions"><button class="admin-row-btn del" onclick="deleteTableRow(this)" title="Delete row">✕</button></span></td>';

        var tbody = document.querySelector("#policyTable tbody");
        tbody.insertBefore(tr, tbody.firstChild);

        // Clear form
        document.getElementById("newDocTitle").value = "";
        document.getElementById("newDocAuth").value = "";
        document.getElementById("newDocDate").value = "";
        document.getElementById("newDocDrive").value = "";
        document.getElementById("newDocSummary").value = "";
        hideAddDocModal();
        initTableCache();
        applyFilters();
      }

      function deleteTableRow(btn) {
        if (confirm("Delete this document from the stockroom?")) {
          var row = btn.closest("tr");
          if (row) row.remove();
          initTableCache();
          applyFilters();
        }
      }

      // ── GLOBAL EDIT MODE ─────────────────────────────────
      var isGlobalEditMode = false;

      function toggleGlobalEdit() {
        var btn = document.getElementById("globalEditToggleBtn");
        isGlobalEditMode = !isGlobalEditMode;

        if (isGlobalEditMode) {
          document.body.classList.add("global-edit-mode");
          btn.classList.add("active");
          btn.innerText = "🎯 Select to Edit (ON)";
        } else {
          document.body.classList.remove("global-edit-mode");
          btn.classList.remove("active");
          btn.innerText = "🎯 Select to Edit (OFF)";

          // Remove contenteditable from ALL elements we made editable
          var editables = document.querySelectorAll("[contenteditable='true']");
          for (var i = 0; i < editables.length; i++) {
            editables[i].removeAttribute("contenteditable");
            editables[i].removeAttribute("spellcheck");
          }
        }
      }

      // Intercept clicks in capture phase when global edit mode is on
      document.addEventListener(
        "click",
        function (e) {
          if (!isGlobalEditMode) return;

          // Check if click is inside admin UI. If so, ignore (let it work normally)
          if (
            e.target.closest(".admin-toolbar") ||
            e.target.closest(".admin-overlay") ||
            e.target.closest(".add-doc-modal")
          ) {
            return;
          }

          // Prevent normal click actions (like button clicking or links)
          e.preventDefault();
          e.stopPropagation();

          // Find closest element that makes sense to edit
          var el = e.target;

          // Make editable and focus
          el.setAttribute("contenteditable", "true");
          el.setAttribute("spellcheck", "false");
          el.focus();
        },
        true,
      );

      // ── Export HTML ─────────────────────────────
      function exportHTML() {
        // Temporarily disable admin mode for clean export
        document.body.classList.remove("admin-mode");
        var overlay = document.getElementById("adminOverlay");
        overlay.classList.remove("hidden");

        // Remove contenteditable from all elements
        var editables = document.querySelectorAll("[contenteditable]");
        for (var i = 0; i < editables.length; i++) {
          editables[i].removeAttribute("contenteditable");
        }

        // Hide add doc modal
        var addModal = document.getElementById("addDocModal");
        addModal.classList.remove("visible");

        // Clear password input
        document.getElementById("adminPassInput").value = "";
        document.getElementById("adminLoginError").style.display = "none";

        // Get clean HTML
        var fullHtml = "<!DOCTYPE html>\n" + document.documentElement.outerHTML;

        // Re-enable admin mode
        overlay.classList.add("hidden");
        enableAdminMode();

        // Trigger download
        var blob = new Blob([fullHtml], { type: "text/html;charset=utf-8" });
        var url = URL.createObjectURL(blob);
        var a = document.createElement("a");
        a.href = url;
        a.download = "index.html";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    